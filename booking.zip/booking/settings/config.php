<?php
/* config.php */
return array (
  'version' => '2.1.0',
  'web_title' => 'E-Booking',
  'web_description' => 'ระบบจองห้องประชุม',
  'timezone' => 'Asia/Bangkok',
  'member_status' => 
  array (
    0 => 'สมาชิก',
    1 => 'ผู้ดูแลระบบ',
    2 => 'ผู้รับผิดชอบ',
  ),
  'color_status' => 
  array (
    0 => '#259B24',
    1 => '#FF0000',
    2 => '#0E0EDA',
  ),
  'default_icon' => 'icon-calendar',
  'user_forgot' => 0,
  'user_register' => 0,
  'welcome_email' => 0,
  'booking_w' => 600,
  'booking_status' => 0,
  'booking_notifications' => 0,
  'password_key' => '5dd4a612d31f7',
  'noreply_email' => '',
  'email_charset' => 'utf-8',
  'email_Host' => '10.0.1.7',
  'email_Port' => 25,
  'email_SMTPSecure' => '',
  'email_Username' => 'somkieat@qsncc.com',
  'email_Password' => 'P@ssw0rd',
  'email_use_phpMailer' => 0,
  'email_SMTPAuth' => 1,
);